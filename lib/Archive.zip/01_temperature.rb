def ftoc(num)
    return (num-32.0)* 5.0/9.0
end


def ctof(num)
    return (num*9.0/5.0)+32.0
end