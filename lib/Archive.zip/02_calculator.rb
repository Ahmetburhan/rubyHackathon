def add(val1, val2)
    return val1 + val2
end

def subtract(val1, val2)
    return val1 - val2
end

def multiply(val1, val2)
    return val1 * val2
end

def sum(arr)
    i =  0
    sum =  0
    while i <  arr.length  do
        sum += arr[i]
     i +=1 
     end
    return sum
end

